"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AdminDot {
    constructor(data) {
        this.id = data.id;
        this.name = data.name;
        this.mobile = data.mobile;
    }
}
exports.default = AdminDot;
