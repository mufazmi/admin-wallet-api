"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class MerchantDto {
    constructor(data) {
        this.id = data.id;
        this.name = data.name;
        this.mobile = data.mobile;
    }
}
exports.default = MerchantDto;
